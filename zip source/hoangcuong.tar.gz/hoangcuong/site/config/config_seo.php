<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* File config_seo 
* Date: 28/03/15 18:33:53.
**/
$config['cf_yahoo'] = '11111';
$config['cf_alexa'] = '333333';
$config['cf_google_webmaster'] = '222222';
$config['cf_google_analytics'] = '1111';

/* End of file config_seo*/