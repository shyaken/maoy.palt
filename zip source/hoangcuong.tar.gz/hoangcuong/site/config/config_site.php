<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* File Config_site 
* Date: 30/03/15 08:56:47.
**/
$config['site_name'] = 'Hệ thống CSM';
$config['site_email'] = 'tranngocduoc@gmail.com';
$config['site_des'] = 'Miêu tả';
$config['site_keyword'] = 'Từ khóa';
$config['site_facebook'] = 'Facebook';
$config['site_google'] = 'Google';
$config['site_twitter'] = 'Twitter 1234';

/* End of file config_site*/