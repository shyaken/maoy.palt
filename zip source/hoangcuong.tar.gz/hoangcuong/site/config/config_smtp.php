<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* File config_smtp 
* Date: 31/03/15 19:23:29.
**/
$config['smtp_hostname'] = 'smtp.gmail.com';
$config['smtp_port'] = '457';
$config['smtp_security'] = 'tls';
$config['smtp_username'] = 'imosvn@gmail.com';
$config['smtp_password'] = 'ngocduoc';

/* End of file config_smtp*/