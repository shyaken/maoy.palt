<?php
$autoload['libraries'] = array('session','form_validation','security','auth','pagination','esset','lg','lib_admin');
$autoload['helper'] = array('url','form','icon','string','vstring','lang');
$autoload['config'] = array('config_site');