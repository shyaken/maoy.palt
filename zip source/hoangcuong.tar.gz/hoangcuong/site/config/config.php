<?php
$config['base_url'] = "";
$config['xsl'] = 1;
$config['charset'] = 'utf-8';
$config['query_string'] = FALSE;
$config['suff'] = '';
// Language
$config['muti_language'] = TRUE;
$config['language'] = 'vi';

$config['encryption_key'] = 'xbKjXT56a9Fbqvfr4ztdF2gbQ7vM7zKhe4sGwZ6x';
$config['csrf_protection'] = TRUE; // Hien thi Input trong Form
$config['csrf_name'] = 'token'; // Token Name
$config['store_session_table'] = true; // Lưu session trong db
$config['cookie_prefix']    = "";
$config['cookie_domain']    = "";
$config['cookie_path']        = "/";
$config['cookie_secure']    = FALSE;