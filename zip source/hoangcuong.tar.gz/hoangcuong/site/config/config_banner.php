<?php
$config['config_banner']    = ROOT."site/config/config_banner.php";
require_once($config['config_banner']);  