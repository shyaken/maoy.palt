<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
define('HOST','localhost');
define('USER','admin_masterapk');
define('PASS','racWuLEbwm');
define('DBNAME','admin_masterapk');