<?php
$config['config_file']    = ROOT."site/config/config_contact.php";
require_once($config['config_file']);  