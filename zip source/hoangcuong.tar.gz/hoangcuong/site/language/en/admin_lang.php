<?php
$lang['delete'] = "Delete";
$lang['add'] = "Add new";
$lang['apply'] = "Apply";
$lang['save'] = "Save";
$lang['cancel'] = "Cancel";
$lang['back'] = "Back";
$lang['bang_dieu_khien'] = "Cpanel";
$lang['thanh_vien'] = "Member";
$lang['danh_sach_thanh_vien'] = "List Member";
$lang['them_moi_thanh_vien'] = "Add Member";
$lang['cau_hinh'] = "Config";
$lang['cau_hinh_website'] = "Config site";
$lang['bai_viet'] = "News";
$lang['lien_he'] = "Contact";
$lang['cau_hinh_lien_he'] = "Config contact";
$lang['danh_sach_lien_he'] = "List contact";
$lang['quan_ly_file'] = "File Manager";