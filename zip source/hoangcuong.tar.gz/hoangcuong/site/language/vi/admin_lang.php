<?php
$lang['delete'] = "Xóa";
$lang['add'] = "Thêm mới";
$lang['apply'] = "Áp dụng";
$lang['save'] = "Lưu";
$lang['cancel'] = "Hủy";
$lang['back'] = "Quay lại";
$lang['bang_dieu_khien'] = "Bảng điều khiển";
$lang['thanh_vien'] = "Thành viên";
$lang['danh_sach_thanh_vien'] = "Dánh sách thành viên";
$lang['them_moi_thanh_vien'] = "Thêm mới thành viên";
$lang['cau_hinh'] = "Cấu hình";
$lang['cau_hinh_website'] = "Cấu hình Website";
$lang['bai_viet'] = "Bài viết";
$lang['lien_he'] = "Liên hệ";
$lang['cau_hinh_lien_he'] = "Cấu hình liên hệ";
$lang['danh_sach_lien_he'] = "Danh sách liên hệ";
$lang['quan_ly_file'] = "Quản lý File";