<div id="main-menu" role="navigation">
    <div id="main-menu-inner">
        <ul class="navigation">
            <li>
                <a href="<?php echo base_url()?>"><i class="menu-icon fa fa-desktop"></i><span class="mm-text">Bảng điều khiển</span></a>
            </li>
            <li>
                <a href="<?php echo site_url("term/ds/");?>"><i class="menu-icon fa fa-newspaper-o"></i><span class="mm-text">Danh mục</span></a>
            </li>
        </ul>
    </div>
</div>