<?php
define('HOST','localhost');
define('USER','root');
define('PASS','admin');
define('DBNAME','2015_v4');